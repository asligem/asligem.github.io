from flask import Flask, request, redirect
import requests

app = Flask(__name__)

MERCHANT = 'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX'  # مرچنت کد واقعی را اینجا وارد کنید
ZP_API_REQUEST = "https://api.zarinpal.com/pg/v4/payment/request.json"
ZP_API_VERIFY = "https://api.zarinpal.com/pg/v4/payment/verify.json"
CALLBACK_URL = "https://yourapp.onrender.com/verify"

def get_amount_from_package(package):
    return {
        "80": 30000,
        "420": 120000,
        "880": 230000
    }.get(package, 0)

@app.route("/payment", methods=["POST"])
def payment():
    amount = get_amount_from_package(request.form["package"])
    data = {
        "merchant_id": MERCHANT,
        "amount": amount,
        "callback_url": CALLBACK_URL,
        "description": f"خرید سی‌پی برای کالاف ID: {request.form['userid']}",
        "metadata": {"email": request.form["email"]}
    }
    headers = {"accept": "application/json", "content-type": "application/json"}
    res = requests.post(ZP_API_REQUEST, json=data, headers=headers).json()
    if res["data"]["code"] == 100:
        return redirect(f"https://www.zarinpal.com/pg/StartPay/{res['data']['authority']}")
    return f"خطا در پرداخت: {res}"

@app.route("/verify")
def verify():
    return "وضعیت پرداخت بررسی شد. (صفحه برگشت از زرین‌پال)"
